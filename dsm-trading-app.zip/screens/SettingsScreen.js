import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

export default function SettingsScreen() {
  return (
    <View style={ flex: 1, justifyContent: 'center', alignItems: 'center' }>
      <Text>SettingsScreen 화면입니다.</Text>
    </View>
  );
}
