import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

export default function LogsScreen() {
  return (
    <View style={ flex: 1, justifyContent: 'center', alignItems: 'center' }>
      <Text>LogsScreen 화면입니다.</Text>
    </View>
  );
}
